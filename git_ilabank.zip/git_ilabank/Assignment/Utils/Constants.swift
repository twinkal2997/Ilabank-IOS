//
//  Constants.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import Foundation
import UIKit

let SCREEN_WIDTH = UIScreen.main.bounds.width
let SCREEN_HEIGHT = UIScreen.main.bounds.height

//MARK:- Colors
public func RGBCOLOR(_ r: CGFloat, _ g: CGFloat , _ b: CGFloat, alpha: CGFloat = 1.0) -> UIColor {
    return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: alpha)
}

let COLOR_WHITE = UIColor.white
let COLOR_BKG = RGBCOLOR(239,239,240)
let COLOR_OFF_WHITE = RGBCOLOR(250,250,250)

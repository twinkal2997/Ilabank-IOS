//
//  CommonFunctions.swift
//  Assignment
//
//  Created by webwerks on 25/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import Foundation
import UIKit

func stringToImage(str: String, _ handler: @escaping ((UIImage?)->())) {
    if let url = URL(string: str) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let data = data {
                let image = UIImage(data: data)
                handler(image)
            }
        }.resume()
    }
}

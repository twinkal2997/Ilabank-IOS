//
//  Constants.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import Foundation

struct Domain {
    static let BASE_URL = "https://reqres.in/"
}
extension Domain {
    static func getBaseUrl() -> String {
        return Domain.BASE_URL
    }
}
struct APIEndpoint {
    static let userList = "api/users"
}

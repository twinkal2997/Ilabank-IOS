//
//  PostViewModel.swift
//  IllhaTask
//
//  Created by A1502 on 24/08/21.
//


import Foundation
import UIKit

//MARK: - Protocol Defining here
protocol UserViewModelProtocol {
    var userDidChange: ((Bool, Bool) -> Void)? { get set }
    func fetchUserListData(page: Int)
}
class UserViewModel: UserViewModelProtocol {

    //MARK: - Internal Properties
    var userDidChange: ((Bool, Bool) -> Void)?
    var requestUserData = [UserModel]()
    
    func fetchUserListData(page: Int) {
        APIServiceManager.instance.fetchUserList(queryString: "page=\(page)") { (result) in
            switch result {
            case .success(let data):
                do {
                    let json = try JSONSerialization.jsonObject(with: data) as! [String:Any]
                    if let arrJson = json["data"] as? [[String:Any]]{
                        var arrUser = [UserModel]()
                        for obj in arrJson{
                            let objDashboard = UserModel(dictInfo: obj)
                            arrUser.append(objDashboard)
                            arrUser.append(objDashboard)
                            arrUser.append(objDashboard)
                        }
                        self.requestUserData = arrUser
                        self.userDidChange!(true, false)
                    }
                } catch {
                    print("JSON Serialization error: ",error)
                }
                break
            case .failure(let error):
                print(error.description)
                self.userDidChange!(false, true)
            }
        }
    }
    
}



//
//  PostModel.swift
//  IllhaTask
//
//  Created by A1502 on 24/08/21.
//

import Foundation
import UIKit

class UserModel: NSObject {
    
    var userId: Int = 0
    var first_name: String = ""
    var last_name: String = ""
    var avatar: String = ""
    
    init(dictInfo:[String:Any]) {
        userId = dictInfo["id"] as? Int ?? 0
        first_name = dictInfo["first_name"] as? String ?? ""
        last_name = dictInfo["last_name"] as? String ?? ""
        avatar = dictInfo["avatar"] as? String ?? ""
    }
    
}

//
//  ViewController.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var lblNoData: UILabel!
    
    var arrSliderImages = [UIImage(named: "dummy1"),UIImage(named: "dummy2"),UIImage(named: "dummy3"),UIImage(named: "dummy4")]
    var userModelObj = UserViewModel()
    var isSearching = false
    var arrFilteredData = [UserModel]()
    let searchBar = UISearchBar()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        registerForTable()
        registerForCollection()
        prepareViewModelObserver()
        userModelObj.requestUserData = []
        fetchUserList(page: 1)
    }
    
    //MARK:- Custom Methods
    func setUI(){
        lblNoData.isHidden = true
        pageControl.numberOfPages = arrSliderImages.count
        searchBar.frame = CGRect(x: 0, y: 15, width: tblView.bounds.width, height: 45)
        searchBar.searchTextField.showDoneButtonOnKeyboard()
    }
    func registerForTable(){
        tblView.delegate = self
        tblView.dataSource = self
        tblView.register(UINib(nibName: "SearchListTableViewCell", bundle: nil), forCellReuseIdentifier: "SearchListTableViewCell")
        tblView.tableFooterView = UIView()
    }
    func registerForCollection(){
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "SliderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "SliderCollectionViewCell")
    }
}

extension HomeViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching{
            return arrFilteredData.count
        }else{
            return userModelObj.requestUserData.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchListTableViewCell", for: indexPath) as! SearchListTableViewCell
        var model: UserModel!
        if isSearching{
            model = arrFilteredData[indexPath.row]
        }else{
            model = userModelObj.requestUserData[indexPath.row]
        }
        cell.lblTitle.text = model.first_name + " " + model.last_name
        stringToImage(str: model.avatar) { (image) in
            DispatchQueue.main.async {
                cell.imgView.image = image
            }
        }
        cell.selectionStyle = .none
        return cell
    }
}

extension HomeViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        searchBar.delegate = self
        searchBar.searchBarStyle = .minimal
        searchBar.placeholder = "Search"
        searchBar.backgroundColor = COLOR_OFF_WHITE
        return searchBar
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

extension HomeViewController: UICollectionViewDelegate{
    
}

extension HomeViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: tblView.bounds.width - 40, height: 220)
    }
}

extension HomeViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrSliderImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SliderCollectionViewCell", for: indexPath) as! SliderCollectionViewCell
        cell.imgView.image = arrSliderImages[indexPath.row]
        return cell
    }
}

extension HomeViewController{
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.isPagingEnabled{
            var visibleRect = CGRect()
            visibleRect.origin = collectionView.contentOffset
            visibleRect.size = collectionView.bounds.size
            let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
            guard let indexPath1 = collectionView.indexPathForItem(at: visiblePoint) else { return }
            pageControl.currentPage = indexPath1.row
            var page = 0
            if pageControl.currentPage ==  0 || pageControl.currentPage ==  2{
                page = 1
            }else if pageControl.currentPage ==  1 || pageControl.currentPage ==  3{
                page = 2
            }
            fetchUserList(page: page)
        }
    }
}

extension HomeViewController {
    func fetchUserList(page: Int) {
        userModelObj.fetchUserListData(page: page)
    }
    func prepareViewModelObserver() {
        userModelObj.userDidChange = { (finished, error) in
            if !error {
                if self.userModelObj.requestUserData.count == 0{
                    self.lblNoData.isHidden = false
                    self.searchBar.isHidden = true
                }else{
                    self.lblNoData.isHidden = true
                    self.searchBar.isHidden = false
                }
                self.reloadTableView()
            }
        }
    }
    func reloadTableView() {
        self.tblView.reloadData()
    }
}

extension HomeViewController: UISearchBarDelegate{
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
    }
    // This method updates filteredData based on the text in the Search Box
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        lblNoData.isHidden = true
        if searchText == "" {
            print("close")
            isSearching = false
            //            searchBar.searchTextField.resignFirstResponder()
            //            self.view.endEditing(true)
        }else{
            isSearching = true
            arrFilteredData = userModelObj.requestUserData.filter({ (model) -> Bool in
                let firstNameText: NSString = model.first_name as NSString
                let lastNameText: NSString = model.last_name as NSString
                let fNameRange = (firstNameText.range(of: searchBar.text!, options: NSString.CompareOptions.caseInsensitive).location)
                let lNameRange = (lastNameText.range(of: searchBar.text!, options: NSString.CompareOptions.caseInsensitive).location)
                if fNameRange != NSNotFound || lNameRange != NSNotFound{
                    return true
                }
                return false
            })
            if arrFilteredData.count == 0{
                self.lblNoData.isHidden = false
            }else{
                self.lblNoData.isHidden = true
            }
        }
        tblView.reloadData()
    }
}

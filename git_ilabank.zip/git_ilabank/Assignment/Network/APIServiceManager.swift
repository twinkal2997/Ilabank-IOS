//
//  Constants.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import Foundation

class APIServiceManager: NSObject, Requestable {
    
    static let instance = APIServiceManager()
    
    func fetchUserList(queryString: String, callback: @escaping Handler) {
        request(url: Domain.getBaseUrl() + APIEndpoint.userList + "?\(queryString)") { (result) in
            callback(result)
        }
    }
    
}

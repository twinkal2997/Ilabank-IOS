//
//  Constants.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import Foundation
import UIKit

enum Result<Value: Decodable> {
    case success(Value)
    case failure(Bool)
}

typealias Handler = (Result<Data>) -> Void

enum NetworkError: Error {
    case nullData
}

protocol Requestable {}

extension Requestable {
    func request(url: String, params: [NSString: Any]? = nil, callback: @escaping Handler) {
        guard let url = URL(string: url) else {
            return
        }
        let task = URLSession.shared.dataTask(with: url,  completionHandler: { (data, response, error) in
            DispatchQueue.main.async {
                if let error = error {
                    print(error.localizedDescription)
                } else if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode == 200 {
                        callback(.success(data!))
                    } else {
                        callback(.failure(true))
                    }
                }
            }
        })
        task.resume()
    }
    
}


//
//  SliderCollectionViewCell.swift
//  Assignment
//
//  Created by webwerks on 24/08/21.
//  Copyright © 2021 webwerks. All rights reserved.
//

import UIKit

class SliderCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgView.layer.cornerRadius = 5
    }

}
